package ritmath;
/**
 * Parent class for terms for polynomials
 *
 * file: Function Factory.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class FunctionFactory extends Object{
    /**Variable x always stay the same*/
    private static Variable x;

    /**
     * Initialization of a constant object
     * @param x number for the constant
     * @return constant object
     */
    public static MathFunction constant(double x){
        Constant constant = new Constant(x);
        return constant;
    }

    /**
     * Initialization of a variable object
     * @return variable x
     */
    public static MathFunction x(){
        if(x == null){
            x = new Variable();
        }
        return x;
    }

    /**
     * Initialization of a sum object
     * @param sum an array of terms
     * @return a sum object
     */
    public static MathFunction sum(MathFunction... sum){
        Sum s = new Sum(sum);
        if(s.isConstant()){
            return new Constant(s.evaluate(0.0));
        }

        return s;

    }
    /**
     * Initialization of a product object
     * If it is a constant, return the evaluation of the product object
     * @param product an array of terms
     * @return a product object
     */
    public static MathFunction product(MathFunction... product) {
        Product p = new Product(product);
        if(p.isConstant()){
            return new Constant(p.evaluate(0.0));
        }

        return p;
    }
    /**
     * Initialization of a sine object
     * @param sine object
     * @return a sine object
     */
    public static MathFunction sine(MathFunction sine){
        return new Sine(sine);
    }
    /**
     * Initialization of a cosine object
     * @param cosine object
     * @return a cosine object
     */
    public static MathFunction cosine(MathFunction cosine){
        return new Cosine(cosine);
    }
}
