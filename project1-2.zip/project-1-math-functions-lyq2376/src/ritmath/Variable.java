package ritmath;
import java.lang.Math;
/**
 * Class for variable terms
 * Evaluating a variable is just x
 * Derivative of a variable is just its coefficient = 1.0
 * Integral of a variable is  (b)^2/2 - (a)^2/2
 * toString method is just x
 * It is not a constant
 *
 * file: Variable.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Variable extends AbstractFunction implements MathFunction {
    /**
     * No need for initialization.
     * X is always the same
     */
    protected Variable (){
    }

    /**
     * Evaluation of a variable
     * @param x coefficient
     * @return x
     */
    @Override
    public double evaluate(double x) {
        return x;
    }

    /**
     * Derivative of a variable
     * Always returns one
     * @return 1.0
     */
    @Override
    public MathFunction derivative() {
        return new Constant(1.0);
    }

    /**
     * Integration of a variable
     * Formula: (up)^2/2 - (down)^2/2
     * @param up upper bound of an integral
     * @param down lower bound of an integral
     * @return (up)^2/2 - (down)^2/2
     */
    @Override
    public double integral(double down, double up, int acc) {
        return ((up*up) -(down*down))/2;
    }

    /**
     * Variable is not a constant
     * @return false
     */
    @Override
    public boolean isConstant() {
        return false;
    }

    /**
     * String representation of a variable
     * @return x as a string
     */
    @Override
    public String toString() {
        return "x";
    }
}
