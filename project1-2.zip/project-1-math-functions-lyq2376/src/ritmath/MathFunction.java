package ritmath;

/**
 * Interface for a math function
 * Foundation of a expression/term
 *
 * file: MathFunction.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public interface MathFunction {
    /**Evaluating a part of a polynomial*/
    double evaluate(double x);
    /**Taking the derivative of a function or term*/
    MathFunction derivative();
    /**Taking the integral of a function*/
    double integral(double up, double down, int c);
    /**Checking to see if a term is a constant or not*/
    boolean isConstant();
}
