package ritmath;
/**
 * Class for a cosine object
 * A cosine object is initialized
 * To evaluate a cosine object, plug in x for the term and do cos(term(x))
 * derivative of a cosine term is -1 * sine(term) *derivative of term
 * toString is usually cos(term) unless if it is purely a constant
 * in which the toString of that constant is returned
 *
 * file: Cosine.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Cosine extends AbstractFunction implements MathFunction {
    /**Private cosine object**/
    private final MathFunction cosi;

    /**
     * Make the private cosine object equal to the parameter
     * @param cosine cosine object
     */
    public Cosine(MathFunction cosine) {
        this.cosi = cosine;

    }
    /**
     * Returns the cosine value of the term evaluated at x
     * @param x a number to plug in
     * @return cos(term evaluated at x)
     */
    public double evaluate(double x) {
        return Math.cos(cosi.evaluate(x));
    }

    /**
     * Make a derivative array with the length of 3
     * Derivative of a cosine object is -1 * sine(term) *derivative of term
     * 1st index = -1
     * 2nd index = sine(term)
     * 3rd index = derivative of term
     * The derivative array will go to the product method in Function Factory
     * @return FunctionFactory.product(deriv)
     */
    public MathFunction derivative() {
        MathFunction[] deriv = new MathFunction[3];
        deriv[0] = FunctionFactory.constant(-1.0);
        deriv[1] = FunctionFactory.sine(this.cosi);
        deriv[2] = this.cosi.derivative();
        return FunctionFactory.product(deriv);
    }


    /**
     * Check if the cosine object is constant
     * @return false if it is not constant, else true if it is
     */
    public boolean isConstant() {
        return this.cosi.isConstant();
    }
    /**
     * String representation of a cosine object
     * If the cosine object has one term, then it takes the toString of the evaluated term
     * Else put toStrings as in cos( term )
     * @return the toStrings of the cosine object
     */
    @Override
    public String toString() {
        if (isConstant()) {
            return String.valueOf(this.evaluate(0));
        }
        return "cos( " + this.cosi + " )";
    }
}
