package ritmath;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Class for polynomials full of products
 * The product array will first go through normalization to make it simpler
 * Evaluating a product polynomial is multiplying all the terms while plugging in a number for x
 * Derivative of a product polynomial is through the product rule
 * To find if the product array is a constant, it has to stay true in an enhanced for loop
 * If the polynomial has one term, then it takes the toString of that term
 * Else put toStrings of each term between parentheses
 *
 * file: Product.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Product extends AbstractFunction implements MathFunction{
    /**Array of terms in an algebraic expression full of products*/
    private MathFunction[] products;

    /**
     * Initialization of the sum array
     * Normalizing the product array for simplification
     * @param product array of algebraic terms
     */
    public Product(MathFunction[] product){
        this.products = product;
       Normalize();
    }
    /**
     * Normalization of a product array
     * if the product array is empty, add a constant object of 1.0
     * else go through the array to check for constants
     * if the index of the array is a constant, then it will be added to a double variable that is 1.0
     * since 0*something = 0
     * else if the index will be added to an array list
     * if the double variable is not equal to 0 or the arraylist is empty
     * add the constant to the arraylist
     * else if the constant is 0, clear the arraylist and add the constant in it
     * in the end use the .toArray method to turn the ArrayList into a native array and make it equal to the private array
     */
    public void Normalize() {
        if (products.length == 0){
            MathFunction[]Normalize = new MathFunction[1];
            Normalize[0] = FunctionFactory.constant(1.0);
            this.products=Normalize;
        }
        else {
            double pro = 1.0;
            ArrayList<MathFunction> math = new ArrayList<>();
            for (MathFunction p : products) {
                if (p.isConstant()) {
                    pro = pro * p.evaluate(0);
                } else {
                    math.add(p);
                }
            }
            if(pro != 1.0 || math.isEmpty()){
                Constant zero = new Constant(pro);
                math.add(zero);
            }
            if (pro == 0.0) {
                Constant zero = new Constant(0.0);
                math.clear();
                math.add(zero);
            }
            this.products = math.toArray(new MathFunction[0]);
        }

    }
    /**
     * Evaluation of a pro polynomial
     * X is plugged in for some number
     * A double variable will be multiplied by each evaluation of an index in the sum array
     * @param x a number to plug in to the term
     * @return eval (evaluated number)
     */
    public double evaluate(double x) {
        double eval = 1.0;
        for (int i = 0; i < this.products.length; i++) {
            eval *= this.products[i].evaluate(x);
        }
        return eval;
    }

    /**
     * Derivative of a pro
     * First an array of sum terms will be initialized
     * There will be a nested for loop that will go through each index of the product array
     * product rule is f'gh + fg'h + fgh'
     * Within the first for loop, have a product term array be initialized
     * the next for loop is where the derivatives and regular terms will be added
     * after each iteration of the nested for loop, t\
     * the result will be added to the sum term array in the first for loop
     * when the whole for loop is done iterating
     * the sum array will go to the sum array in the FunctionFactory
     * @return FunctionFactory.sum(sumTerms)
     *
     */
    public MathFunction derivative() {
        MathFunction [] sumTerms = new MathFunction[this.products.length];
        for(int i = 0; i < this.products.length; i++){
            MathFunction [] procTerms = new MathFunction[this.products.length];
            for(int j = 0; j <this.products.length; j++){
                if(i == j){
                    procTerms[j] = this.products[j].derivative();
                }
              else{
                    procTerms[j]=products[j];
               }
            }
           sumTerms[sumTerms.length-1-i] =FunctionFactory.product(procTerms);
        }
        return FunctionFactory.sum(sumTerms);
    }

    /**
     * Go through each index of the sum array to check it is truly constant
     * @return false if it is not constant, else true if it is
     */
    public boolean isConstant() {
        for(MathFunction i: products){
            if(!(i.isConstant())){
                return false;
            }
        }
        return true;
    }
    /**
     * String representation of a product polynomial
     * If the polynomial has one term, then it takes the toString of that term
     * Else put toStrings of each term between parentheses
     * @return the toStrings of each term in the polynomial
     */
    @Override
    public String toString() {
        if(this.products.length==1){
            return products[0].toString();
        }
        String add = "( ";
        for(int i = 0; i<this.products.length; i++){
            if(products[i].isConstant()){
                add+= "";
            }
            String s = this.products[i].toString();
            add += "" +s;
            if(i != this.products.length-1){
                add+= " * ";
            }
        }
        return add + " )";
        }
    }

