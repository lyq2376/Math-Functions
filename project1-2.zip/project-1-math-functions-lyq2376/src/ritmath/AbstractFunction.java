package ritmath;

/**
 * Class for the trapezoidal rule for integration
 * Main Class for integrals
 * file: AbstractFunction.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public abstract class AbstractFunction implements MathFunction {
    /**
     * Uses the trapezoid rule of the product, sine, and cosine class
     * Trapezoid: b-a/n(yo + 2[y1...yn-1] + yn]
     * @param acc accuracy
     * @param up upper bound of an integral
     * @param down lower bound of an integral
     * return the integral of an expression using the trapezoid rule
     */
    public double integral(double down, double up, int acc) {
        double h = (up - down) / acc;
        double x = down;
        double ac = 0.0;
        for (int i = 0; i <= acc; i++) {
            if (i != 0 && i != acc) {
                ac += evaluate(x) * 2;
            } else {
                ac += evaluate(x);
            }
            x+=h;
        }
        return ac*h/2;
    }

    /**
     * toString method is abstract
     * so it can be used by other classes that extend to AbstractFunction
     * @return toString of child classes
     */
    public abstract String toString();
}
