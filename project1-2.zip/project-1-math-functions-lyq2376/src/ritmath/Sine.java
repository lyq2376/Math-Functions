package ritmath;
/**
 * Class for a sine object
 * A sine object is initialized
 * To evaluate a cosine object, plug in x for the term and do sin(term(x))
 * derivative of a cosine term is cos(term) *derivative of term
 * toString is usually sin(term) unless if it is purely a constant
 * in which the toString of that constant is returned
 *
 * file: Sine.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Sine extends AbstractFunction implements MathFunction{
    /**Private sine object*/
    private final MathFunction sine;

    /**
     * Make the private sine object equal to the parameter
     * @param sine sine object
     */
    public Sine (MathFunction sine){
        this.sine = sine;
    }
    /**
     * Returns the sine value of the term evaluated at x
     * @param x a number to plug in
     * @return sin(term evaluated at x)
     */
    public double evaluate(double x) {
        return Math.sin(sine.evaluate(x));
    }
    /**
     * Make a derivative array with the length of 2
     * Derivative of a cosine object is cos(term) *derivative of term
     * 1st index = cos(term)
     * 2nd index = derivative of term
     * The derivative array will go to the product method in Function Factory
     * @return FunctionFactory.product(deriv)
     */
    public MathFunction derivative() {
        MathFunction [] deriv = new MathFunction[2];
        deriv[0] = FunctionFactory.cosine(this.sine);
        deriv[1] = this.sine.derivative();
        return FunctionFactory.product(deriv);
    }

    /**
     * Check if the sine object is constant
     * @return false if it is not constant, else true if it is
     */
    public boolean isConstant() {
        return this.sine.isConstant();
    }
    /**
     * String representation of a sine object
     * If the sine object has one term, then it takes the toString of the evaluated term
     * Else put toStrings as in sin( term )
     * @return the toStrings of the sine object
     */
    @Override
    public String toString() {
        if(isConstant()){
            return String.valueOf(this.evaluate(0));
        }
        return "sin( " + this.sine + " )";
    }
}
