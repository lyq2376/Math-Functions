package ritmath;

import java.util.ArrayList;

/**
 * Class for polynomials full of sums
 * The Sum array will first go through normalization to make it simpler
 * Evaluating a sum polynomial is adding all the terms while plugging in a number for x
 * Derivative of a sum polynomial is adding all derivatives in the polynomial
 * To find if the sum array is a constant, it has to stay true in an enhanced for loop
 * If the polynomial has one term, then it takes the toString of that term
 * Else put toStrings of each term between parentheses
 * Integral of a sum is adding all the integrals of each term
 *
 * file: Sum.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Sum extends AbstractFunction implements MathFunction {
    /**
     * Array of terms in an algebraic expression full of sums
     */
    private MathFunction[] sum;

    /**
     * Initialization of the sum array
     * Normalizing the sum array for simplification
     * @param sums array of algebraic terms
     */
    public Sum(MathFunction[] sums) {
        this.sum = sums;
        Normalize();
    }
    /**
     * Normalization of a sum array
     * if the sum array is empty, add a constant object of 0.0
     * else go through the array to check for constants
     * if the index of the array is a constant, then it will be added to a double variable
     * else if the index will be added to an array list
     * if the double variable is not equal to 0 or the arraylist is empty
     * add the constant to the arraylist
     * in the end use the .toArray method to turn the ArrayList into a native array and make it equal to the private array
     */
    public void Normalize() {
        if (sum.length == 0) {
            MathFunction[] Normalize = new MathFunction[1];
            Normalize[0] = FunctionFactory.constant(0.0);
            this.sum = Normalize;
        }
        else {
            double add = 0.0;
            ArrayList<MathFunction> math = new ArrayList<>();
            for (MathFunction a : sum) {
                if (a.isConstant()) {
                    add = add + a.evaluate(0);
                } else {
                    math.add(a);
                }
            }
            if (add != 0.0 || math.isEmpty()) {
                Constant zero = new Constant(add);
                math.add(zero);
            }
            this.sum = math.toArray(new MathFunction[0]);
        }
    }
    @Override
    /**
     * Evaluation of a sum polynomial
     * X is plugged in for some number
     * A double variable will be added by each evaluation of an index in the sum array
     * @param x a number to plug in
     * @return eval (evaluated number)
     */
    public double evaluate(double x) {
        double eval = 0.0;
        for (int i = 0; i < this.sum.length; i++) {
            eval += this.sum[i].evaluate(x);
        }
        return eval;
    }

    @Override
    /**
     * Derivative of a sum
     * Adding the derivatives of each term in the polynomial
     */
    public MathFunction derivative() {
        MathFunction[] deriv = new MathFunction[this.sum.length];
        for (int i = 0; i < this.sum.length; i++) {
            deriv[i] = this.sum[i].derivative();
        }

        return FunctionFactory.sum(deriv);
    }
    /**
     * Integration of a sum polynomial
     * An integral of sums is all the integrals of the sum array being added to each other
     * @param up upper bound of an integral
     * @param down lower bound of an integral
     * @return the integration of each term
     */
    @Override
    public double integral(double up, double down, int c) {
        double sumIntegral = 0.0;
        for(int i=0; i<this.sum.length; i++){
            sumIntegral += this.sum[i].integral(up, down, c);
        }
        return sumIntegral;
    }

    /**
     * Go through each index of the sum array to check it is truly constant
     * @return false if it is not constant, else true if it is
     */
    @Override
    public boolean isConstant() {
        for(MathFunction i: sum){
            if(!(i.isConstant())){
                return false;
            }
        }
        return true;
    }

    /**
     * String representation of a sum polynomia
     * If the polynomial has one term, then it takes the toString of that term
     * Else put toStrings of each term between parentheses
     * @return the toStrings of each term in the polynomial
     */
    @Override
    public String toString() {
        if(this.sum.length==1){
            return sum[0].toString();
        }
            String add = "( ";
            for(int i = 0; i<this.sum.length; i++){
                if(sum[i].isConstant()){
                    add+= "";
                }
                String s = this.sum[i].toString();
                add += "" +s;
                if(i != this.sum.length-1){
                    add+= " + ";
                }
            }
            return add + " )";

    }
}