package ritmath;
/**
 * Class for constant terms
 * Evaluating a constant will be equal to the original constant variable
 * Derivative of a constant is 0.0
 * Integral Method is stubbed for Part 1
 * toString method is a string with the constant variable only
 * It is always a constant
 *
 * file: Constant.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Constant extends AbstractFunction implements MathFunction{
    /**Constant variable*/
    private final double variable;

    /**
     * Initialization of the constant variable
     * @param x coefficient
     */
    public Constant(double x){
        this.variable = x;
    }

    /**
     * Evaluation of a constant
     * @param x different constant
     * @return this.variable (original constant variable)
     */
    public double evaluate(double x) {
        return this.variable;
    }

    /**
     * Derivative of a constant
     * @return 0.0
     */
    @Override
    public MathFunction derivative() {
        return new Constant(0.0);
    }

    /**
     * Integration of a constant is x
     * @param up upper bound of an integral
     * @param down lower bound of an integral
     * @return up*constant - down*constant
     */
    @Override
    public double integral(double down, double up, int acc) {
        return this.variable*up - this.variable*down;
    }

    /**
     * Constant is a constant
     * @return true
     */
    @Override
    public boolean isConstant() {
        return true;
    }

    /**
     * String representation of a constant
     * @return constant with an empty string
     */
    @Override
    public String toString() {
        return this.variable + "";
    }
}
